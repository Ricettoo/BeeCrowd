import java.util.Scanner;

public class PositivosEMedia{
    public static void main(String[] args) {
        Scanner Leia = new Scanner(System.in);
        double A = Leia.nextDouble();
        double B = Leia.nextDouble();
        double C = Leia.nextDouble();
        double D = Leia.nextDouble();
        double E = Leia.nextDouble();
        double F = Leia.nextDouble();
        Leia.close();

        int positivo = 0;
        double somapositivo = 0;

        if (A > 0){
            positivo++;
            somapositivo += A;
        }
        if (B > 0){
            positivo++;
            somapositivo += B;
        }
        if (C > 0){
            positivo++;
            somapositivo +=C;
        }
        if (D > 0){
            positivo++;
            somapositivo +=D;
        }
        if (E > 0){
            positivo++;
            somapositivo +=E;
        }
        
        if (F > 0){
            positivo++;
            somapositivo +=F;
        }

    double media = somapositivo /positivo;
    System.out.printf("%d valores positivos\n%.2f", positivo, media);
    }
}